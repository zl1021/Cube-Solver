mmm saved about 18 characters blah

Tomas Sirgedas (DjinnKahn)
ts_ubq@yahoo.com
Ann Arbor, MI

I implemented Thistlethwaite's algorithm as described on Jaap Scherphuis' web page:
http://www.geocities.com/jaapsch/puzzles/cube3.htm
Jaap also helped me out through email... He explained what was meant by tetrad twist.  He pointed me in the right direction to discover how to assign a tetrad twist value to a G2 position.  So, many thanks to him.

It compiles with Visual C++ and hopefully g++
It averages about 32 moves on a random cube
A random cube is solved in about .12 seconds on average on my 1.33GHz

